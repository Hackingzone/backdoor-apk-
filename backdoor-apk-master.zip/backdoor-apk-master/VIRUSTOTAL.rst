Virus Total Results
-------------------

(2016-11-30)
++++++++++++

- File: Pandora_7.4.apk
- SHA256: 5a56757ec53970d93aa769e3abb6a915be7c4891f0437914f2541e8a7920b439
- Payload: android/meterpreter/reverse_https
- LHOST: 10.6.9.31
- LPORT: 443
- Notes: Two mobile antivirus detections
- URL: https://www.virustotal.com/en/file/5a56757ec53970d93aa769e3abb6a915be7c4891f0437914f2541e8a7920b439/analysis/1480520820/

(2016-11-29)
++++++++++++
- File: AdobeReader.apk
- SHA256: 889b230b6faaeecdb9c0036bb51ae96741013e2c353bf2b62f35a613ac84298d
- Payload: android/meterpreter/reverse_https
- LHOST: 10.6.9.31
- LPORT: 443
- Notes: One mobile antivirus detection
- URL: https://www.virustotal.com/en/file/889b230b6faaeecdb9c0036bb51ae96741013e2c353bf2b62f35a613ac84298d/analysis/1480452214/

(2016-10-18)
++++++++++++
- File: Pandora_7.4.apk
- SHA256: c5ed8c2ca32e4a9e713b57ce7e738b7bbf73533b313bfa57049321a855215d5b
- Payload: android/meterpreter/reverse_https
- LHOST: 10.6.9.31
- LPORT: 443
- Notes: One mobile antivirus detection
- URL: https://www.virustotal.com/en/file/c5ed8c2ca32e4a9e713b57ce7e738b7bbf73533b313bfa57049321a855215d5b/analysis/1476769045/

(2016-07-29)
++++++++++++
- File: Pandora_7.4.apk
- SHA256: 2b4b2d59f7fb40f1a6b1ef39feb863878a144995066afc449a5d9e44bd0678c8
- Payload: android/meterpreter/reverse_https
- LHOST: NNN.NN.2.82
- LPORT: 443
- Notes: No mobile antivirus detections
- URL: https://www.virustotal.com/en/file/2b4b2d59f7fb40f1a6b1ef39feb863878a144995066afc449a5d9e44bd0678c8/analysis/1469825538/

(2016-06-28)
++++++++++++
- File: AdobeReader.apk
- SHA256: 4261a2cefe3f8ba9319cb120d12f2e8fb86c18dceaa5f0b9a15381dbc725bebf
- Payload: android/meterpreter/reverse_tcp
- LHOST: 10.6.9.31
- LPORT: 1337
- Notes: First time with no mobile antivirus detection on virustotal
- URL: https://www.virustotal.com/en/file/4261a2cefe3f8ba9319cb120d12f2e8fb86c18dceaa5f0b9a15381dbc725bebf/analysis/1467137293/
