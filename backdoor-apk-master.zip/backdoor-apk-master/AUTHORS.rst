backdoor-apk is developed and maintained by Dana James Traversie:

Official Development Team
`````````````````````````

- Dana James Traversie <dtravers@checkpoint.com> (`@dana-at-cp <https://github.com/dana-at-cp>`_), Lead Developer.

Patches and Suggestions
```````````````````````

- John Troony (`@JohnTroony <https://github.com/JohnTroony>`_)
